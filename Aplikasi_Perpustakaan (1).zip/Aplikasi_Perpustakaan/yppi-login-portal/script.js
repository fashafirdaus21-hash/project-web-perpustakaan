document.addEventListener("DOMContentLoaded", function () {
    // 1. Fitur Lihat / Sembunyikan Password (Show/Hide Password)
    const passwordInput = document.getElementById('passwordInput');
    const togglePasswordBtn = document.getElementById('togglePassword');

    if (togglePasswordBtn && passwordInput) {
        togglePasswordBtn.addEventListener('click', function () {
            // Ubah tipe input dari password ke text dan sebaliknya
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
        });
    }

    // 2. Simulasi Proses Validasi Form Login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault(); // Mencegah halaman reload bawaan form
            
            const usernameInput = document.getElementById('usernameInput').value;
            const passInput = passwordInput.value;

            if (usernameInput.trim() === "" || passInput.trim() === "") {
                alert("Username dan Password tidak boleh kosong!");
            } else {
                alert(`Login Berhasil! Selamat datang di YPPI Library Portal, ${usernameInput}.`);
                // Di sini Anda bisa mengarahkan ke halaman dashboard, misal:
                // window.location.href = "dashboard.html";
            }
        });
    }
});