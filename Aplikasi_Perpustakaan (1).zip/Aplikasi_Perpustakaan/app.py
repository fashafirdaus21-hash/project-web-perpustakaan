from flask import Flask, render_template, request, redirect, url_for, session
from koneksi import buat_koneksi

app = Flask(__name__)
app.secret_key = 'kunci_rahasia_perpustakaan'

# 1. Halaman Depan / Login
@app.route('/')
def index():
    return render_template('index.html')

# 2. Proses Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Mengambil data dari input form HTML (bisa pakai id_user atau email)
        input_user = request.form['username']
        input_password = request.form['password']
        
        conn = buat_koneksi()
        cursor = conn.cursor(dictionary=True)
        
        # Mengecek apakah id_user/email dan password cocok dengan tabel database
        query = "SELECT * FROM users WHERE (id_user = %s OR email = %s) AND password_hash = %s"
        cursor.execute(query, (input_user, input_user, input_password))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if user:
            # Simpan sesi login
            session['id_user'] = user['id_user']
            session['nama'] = user['nama']
            session['role'] = user['role']
            
            # Arahkan ke dashboard masing-masing role
            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            elif user['role'] == 'kepsek':
                return redirect(url_for('kepsek_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))
        else:
            return "Login Gagal! ID/Email atau Password salah. <a href='/'>Coba lagi</a>"
            
    return render_template('index.html')

# 3. Dashboard Admin (Mengarahkan ke folder admin/dashboard.html)
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'role' in session and session['role'] == 'admin':
        return render_template('admin/dashboard.html')
    return redirect(url_for('login'))

# 4. Dashboard Kepala Sekolah (Mengarahkan ke folder kepsek/dashboard.html)
@app.route('/kepsek/dashboard')
def kepsek_dashboard():
    if 'role' in session and session['role'] == 'kepsek':
        return render_template('kepsek/dashboard.html')
    return redirect(url_for('login'))

# 5. Dashboard User / Siswa (Mengarahkan ke folder user/dashboard.html)
@app.route('/user/dashboard')
def user_dashboard():
    if 'role' in session and session['role'] == 'siswa':
        return render_template('user/dashboard.html')
    return redirect(url_for('login'))

# Logout route
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)