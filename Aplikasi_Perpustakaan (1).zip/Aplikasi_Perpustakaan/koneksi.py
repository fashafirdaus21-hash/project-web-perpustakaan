import mysql.connector

def buat_koneksi():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="db_perpustakaan"  # <-- Ubah jadi db_perpustakaan sesuai phpMyAdmin
    )
    return conn